<?php
/**
 * Represents a Factual Match query.
 * @author Tyler
 */
class MatchQuery extends ResolveQuery {
	
  const RESPONSETYPE = "MatchResponse";
  
}
?>
